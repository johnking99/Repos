﻿using System;

namespace random1
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();

            rand.Next(1, 101);

            int randomnumber = rand.Next(1, 101);
            
            while (randomnumber != 33)
            {
                Console.WriteLine("Guess a number between 1 and 100");
                int.TryParse(Console.ReadLine(), out randomnumber);

                if (randomnumber > 33)
                {
                    Console.WriteLine("Wrong.");
                }
                else if (randomnumber < 33)
                {
                    Console.WriteLine("Wrong.");
                }
                else if (randomnumber != 33)
                {
                    Console.WriteLine("You guessed correctly!");
                }

            }
        }
    }
}
